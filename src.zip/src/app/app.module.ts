import { UsersService } from './services/users.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';



import { AppRoutingModule } from './app-routing.module';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { EmployeesComponent } from './employees/employees.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { NestedComponentsComponent } from './nested-components/nested-components.component';
import { FormValidationComponent } from './form-validation/form-validation.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { BgColorDirective } from './directives/bg-color.directive';
import { FgColorDirective } from './directives/fg-color.directive';
import { NgShowDirective } from './directives/ng-show.directive';
import { NgHideDirective } from './directives/ng-hide.directive';
import { StudentComponent } from './student/student.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';

@NgModule({
  declarations: [//components,pipes,directives
    AppComponent, AngularBasicsComponent, 
    TechnologiesComponent, AngularPipesComponent, 
    GenderPipe, OrderByPipe, EmployeesComponent, 
    CaseStudyComponent, CustomDirectivesComponent, 
    NestedComponentsComponent, FormValidationComponent, 
    UsersComponent, PostsComponent, CommentsComponent, 
    TodosComponent, AlbumsComponent, PhotosComponent, 
    UsersListComponent, UsersTableComponent, ParentComponent,
     ChildComponent, BgColorDirective, FgColorDirective, 
     NgShowDirective, NgHideDirective, StudentComponent, ReactiveFormComponent
  ],
  imports: [  //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [UsersService],//providers  //module level service
  bootstrap: [AppComponent]//components
})
export class AppModule { }
