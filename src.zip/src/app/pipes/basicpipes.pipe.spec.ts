import { BasicpipesPipe } from './basicpipes.pipe';

describe('BasicpipesPipe', () => {
  it('create an instance', () => {
    const pipe = new BasicpipesPipe();
    expect(pipe).toBeTruthy();
  });
});
