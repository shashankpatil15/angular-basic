import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whychoose',
  templateUrl: './whychoose.component.html',
  styleUrls: ['./whychoose.component.css']
})
export class WhychooseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
