import { HovertextDirective } from './hovertext.directive';

describe('HovertextDirective', () => {
  it('should create an instance', () => {
    const directive = new HovertextDirective();
    expect(directive).toBeTruthy();
  });
});
