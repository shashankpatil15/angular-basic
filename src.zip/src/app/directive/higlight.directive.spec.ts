import { HiglightDirective } from './higlight.directive';

describe('HiglightDirective', () => {
  it('should create an instance', () => {
    const directive = new HiglightDirective();
    expect(directive).toBeTruthy();
  });
});
