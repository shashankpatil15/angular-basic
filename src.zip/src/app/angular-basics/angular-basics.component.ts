import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {

  title = 'Angular 7 Basic';

  colors = ['RED','GREEN','BLUE','MAGENTA','BROWN'];
  day = 1;
  max=8;
  min=1;
  name ={fname:'shashank',lname:'patil'};
  show = true;
  hide = false;


  constructor() {
    console.log("Angular 7 Basic comp created");
   }

  ngOnInit() {
    console.log("Angular 7 Basic comp initialized...");
  }

  ngOnDestroy() {
    console.log("Angular 7 Basic comp initialized...");
  }

  showHide() {
    this.hide=!this.hide;
  }

}
