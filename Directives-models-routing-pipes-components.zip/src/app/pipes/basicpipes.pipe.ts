import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'basicpipes'
})
export class BasicpipesPipe implements PipeTransform {

  power ='5';
  factor = 1;
  transform(value: number, exponent: string): number{
    let exp = parseFloat(exponent);
    return Math.pow(value, isNaN(exp) ? 1 : exp);
  }

}
