import { Directive, ElementRef, HostListener, Input } from '@angular/core'; 

//Binds a CSS event to a host listener and supplies configuration metadata. Angular invokes the supplied handler method when the host element emits the specified event, and updates the bound element with the result. If the handler method returns false, applies preventDefault on the bound element.

@Directive({
  selector: '[appHovertext]'
})

export class HovertextDirective {

  constructor( private el: ElementRef) { }

  @Input('appHovertext') highlighColor: string;

  @HostListener('mouseenter') onMouseEnter(){
    this.hovertext(this.highlighColor || 'yellow');
  }

  /*@HostListener('mouseenter') onMouseEnter(){
    this.hovertext('yellow');
  }*/
  @HostListener('mouseleave') onmouseleave() {
    this.hovertext(null);
  }
  private hovertext(color:string){
    this.el.nativeElement.style.backgroundColor = color;
  }
}
