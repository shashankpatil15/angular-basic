import { Directive, ElementRef} from '@angular/core'; 
//ElementRef A wrapper around a native element inside of a View

@Directive({ //@Directive decorator
  selector: '[appHiglight]'
})
export class HiglightDirective { //controller class
// logic for the directive
  constructor(el: ElementRef) { 
    el.nativeElement.style.backgroundColor ='yellow';
  }

}
