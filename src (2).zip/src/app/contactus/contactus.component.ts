import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',  
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  city = ["Pune","Ahmednagar","Akola","Amravati","Aurangabad","Beed","Bhandara","Buldhana","Chandrapur",
  "Dhule",
  "Gadchiroli",
  "Gondia",
  "Hingoli", "Jalgaon",
  "Jalna",
  "Kolhapur",
  "Latur",
  "Mumbai",
  "Nagpur",
  "Nanded",
  "Nandurbar",
  "Nashik",
  "Osmanabad",
  "Palghar",
  "Parbhani",
  "Pune",
  "Raigad",
  "Ratnagiri",
  "Sangli",
"Satara",
"Sindhudurg",
"Solapur",
"Thane",
"Wardha",
"Washim",
"Yavatmal"]
clickmessage ='';

onClick(){
  alert("Submited Sucessfully");
}
  constructor() { }

  ngOnInit() {
  }

}
