import { Component } from '@angular/core';

@Component({
  selector: 'app-angular-pipes',
  templateUrl: './angular-pipes.component.html',
  styleUrls: ['./angular-pipes.component.css']
})
export class AngularPipesComponent  {
  constructor() {
    console.log("AngularPipesComponent created...");

   }

  ngOnInit() {
    console.log("AngularPipesComponent initialized...");
    
  }
  
  ngOnDestroy() {
    console.log("AngularPipesComponent destroyed...");
    
  }
  
}
