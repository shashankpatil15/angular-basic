import { Component  } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent  {

  constructor() {
    console.log("TechnologiesComponent created...");

   }

  ngOnInit() {
    console.log("TechnologiesComponent initialized...");
    
  }
  
  ngOnDestroy() {
    console.log("TechnologiesComponent destroyed...");
    
  }

}
